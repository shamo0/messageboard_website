<?php
	$db_hostname = 'localhost';
	$db_database = 'messageboard';
	$db_username = 'root';
	$db_password = '';
?>